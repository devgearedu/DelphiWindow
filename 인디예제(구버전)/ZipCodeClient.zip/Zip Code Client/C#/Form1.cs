using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Collections.Specialized;
using Indy.Sockets;

namespace ZipCodeClient {
	public class Form1 : System.Windows.Forms.Form {
    private System.Windows.Forms.Button butnLookup;
    private System.Windows.Forms.Button butnClear;
    private System.Windows.Forms.ListBox lboxResults;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox textInput;
		private System.ComponentModel.Container components = null;

		public Form1() {
			InitializeComponent();
		}

		protected override void Dispose( bool disposing ) {
			if( disposing ) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.lboxResults = new System.Windows.Forms.ListBox();
      this.butnLookup = new System.Windows.Forms.Button();
      this.butnClear = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.textInput = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // lboxResults
      // 
      this.lboxResults.Dock = System.Windows.Forms.DockStyle.Right;
      this.lboxResults.Location = new System.Drawing.Point(192, 0);
      this.lboxResults.Name = "lboxResults";
      this.lboxResults.Size = new System.Drawing.Size(272, 264);
      this.lboxResults.TabIndex = 1;
      // 
      // butnLookup
      // 
      this.butnLookup.Location = new System.Drawing.Point(104, 8);
      this.butnLookup.Name = "butnLookup";
      this.butnLookup.TabIndex = 2;
      this.butnLookup.Text = "&Lookup";
      this.butnLookup.Click += new System.EventHandler(this.butnLookup_Click);
      // 
      // butnClear
      // 
      this.butnClear.Location = new System.Drawing.Point(104, 40);
      this.butnClear.Name = "butnClear";
      this.butnClear.TabIndex = 3;
      this.butnClear.Text = "&Clear";
      this.butnClear.Click += new System.EventHandler(this.butnClear_Click);
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(104, 88);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(80, 96);
      this.label1.TabIndex = 4;
      this.label1.Text = "Enter zip codes one per line in the memo box to the left and then click Lookup.";
      // 
      // textInput
      // 
      this.textInput.Dock = System.Windows.Forms.DockStyle.Left;
      this.textInput.Location = new System.Drawing.Point(0, 0);
      this.textInput.Multiline = true;
      this.textInput.Name = "textInput";
      this.textInput.Size = new System.Drawing.Size(96, 266);
      this.textInput.TabIndex = 5;
      this.textInput.Text = "16412\r\n37642";
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(464, 266);
      this.Controls.Add(this.textInput);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.butnClear);
      this.Controls.Add(this.butnLookup);
      this.Controls.Add(this.lboxResults);
      this.Name = "Form1";
      this.Text = "Zip Code Client";
      this.ResumeLayout(false);

    }
		#endregion

		[STAThread]
		static void Main() {
			Application.Run(new Form1());
		}

    private void butnClear_Click(object sender, System.EventArgs e) {
      textInput.Clear();
      lboxResults.Items.Clear();
    }

    private void butnLookup_Click(object sender, System.EventArgs e) {
      butnLookup.Enabled = false;
      try {
        lboxResults.Items.Clear();
        using (TCPClient LClient = new TCPClient()) {
          LClient.Connect("127.0.01", 6000); 
          try {
            // Read the welcome message
            LClient.GetResponse(200);
            for (int i = 0; i <= LClient.LastCmdResult.Text.Count - 1; i++) {
              lboxResults.Items.Add(LClient.LastCmdResult.Text[i]);
            }
            lboxResults.Items.Add("");
            // Submit each zip code and read the result
            for (int i = 0; i <= textInput.Lines.Length - 1; i++) {
              LClient.SendCmd("Lookup " + textInput.Lines[i], 201);
              StringCollection LResults = new StringCollection();
              LClient.IOHandler.Capture(LResults);
              for (int j = 0; j <= LResults.Count - 1; j++) {
                lboxResults.Items.Add(LResults[j]);
              }
              lboxResults.Items.Add("");
            }
            LClient.SendCmd("Quit", 202);
          }
          finally {
            LClient.Disconnect();
          }
        }
      }
      finally {
        butnLookup.Enabled = true;
      }
    }
	}
}
