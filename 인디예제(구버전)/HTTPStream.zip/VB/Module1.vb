Imports System.IO
Imports System.Text
Imports Indy.Sockets

Module Module1

  Sub Main()
    ' This will put the index.html in the source directory
    Dim LOutput As New FileStream( _
     New FileInfo(System.Windows.Forms.Application.ExecutablePath).DirectoryName _
     + "\..\index.html", FileMode.Create)

    With New HTTP
      .Get("http://www.atozed.com", .CType(LOutput))
    End With
  End Sub

End Module
