using System;
using System.IO;
using Indy.Sockets;

namespace IntroHTTP {
  class Class1 {
    static void Main() {
      using (FileStream LOutput = new FileStream(
       // This will put the index.html in the source directory
       new FileInfo(System.Windows.Forms.Application.ExecutablePath)
       .DirectoryName + @"\..\..\index.html", FileMode.Create)) {
        using (HTTP LHTTP = new HTTP()) {
          LHTTP.Get("http://www.atozed.com/", LOutput);
        }
      }
    }
  }
}