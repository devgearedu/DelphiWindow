using System;
using Indy.Sockets;

namespace IntroHTTP {
	class Class1 {
		[STAThread]
		static void Main(string[] args) {
      String LResult;
      using (HTTP LHTTP = new HTTP()) {
        LResult = LHTTP.Get("http://www.atozed.com");
      }
      Console.WriteLine(LResult);
      Console.WriteLine("Press Enter");
      Console.ReadLine();
		}
	}
}
