Imports Indy.Sockets

Module Module1
  Sub Main()
    Dim LResult As String
    Dim LHTTP As New HTTP

    LResult = LHTTP.Get("http://www.atozed.com")

    Console.WriteLine(LResult)
    Console.WriteLine("Press Enter")
    Console.ReadLine()
  End Sub
End Module
