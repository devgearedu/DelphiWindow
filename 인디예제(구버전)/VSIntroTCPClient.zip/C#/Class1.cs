using System;
using Indy.Sockets;

namespace Intro
{
  class Class1
    {
      [STAThread]
      static void Main(string[] args)
	    {
        using (TCPClient LClient = new TCPClient())
        {
          LClient.Host = "news.atozedsoftware.com";
          LClient.Port = 119;
          LClient.Connect(); 
          try 
          {
            Console.WriteLine("Connected.");
            Console.WriteLine(LClient.IOHandler.ReadLn());
            LClient.IOHandler.WriteLn("Quit");
            Console.WriteLine(LClient.IOHandler.ReadLn());
          }
          finally 
          { 
            LClient.Disconnect(); 
            Console.WriteLine("Disconnected.");
          }
        }
	      Console.WriteLine("Press Enter");
	      Console.ReadLine();
      }
    }
}
