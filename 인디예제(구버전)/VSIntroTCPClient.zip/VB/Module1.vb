Imports Indy.Sockets

Module Module1
  Sub Main()
    With New TCPClient
      .Host = "news.atozedsoftware.com"
      .Port = 119
      .Connect()
      Try
        Console.WriteLine("Connected.")
        Console.WriteLine(.IOHandler.ReadLn)
        .IOHandler.WriteLn("Quit")
        Console.WriteLine(.IOHandler.ReadLn)
      Finally
        .Disconnect()
        Console.WriteLine("Disconnected.")
      End Try
    End With
    Console.WriteLine("Press Enter")
    Console.ReadLine()
  End Sub
End Module
