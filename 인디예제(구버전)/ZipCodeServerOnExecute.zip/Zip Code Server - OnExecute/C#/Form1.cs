using System;
using System.Drawing;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using Indy.Sockets;
using Indy.Sockets.Units;

namespace ZipCodeServer_OnExecute
{
	public class Form1 : System.Windows.Forms.Form {
		private System.ComponentModel.Container components = null;
    private TCPServer FServer = new TCPServer();
    private StringDictionary FZipCodeList = new StringDictionary();

		public Form1() {
			InitializeComponent(); 
      
      using (StreamReader LFile = new StreamReader(
       new FileInfo(System.Windows.Forms.Application.ExecutablePath).DirectoryName
       + @"..\..\..\..\..\ZipCodes.dat")) {
        string s;
        string[] t;
        Char[] LSep = new Char[] {'='};
        while ((s = LFile.ReadLine()) != null) {
          t = s.Split(LSep);
          FZipCodeList.Add(t[0], t[1]);
        }
      }

      FServer.OnConnect += new TIdServerThreadEvent(TCPServerConnect);
      FServer.OnExecute += new TIdServerThreadEvent(TCPServerExecute);
      FServer.DefaultPort = 6000;
      FServer.Active = true;
		}

		protected override void Dispose( bool disposing ) {
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 262);
      this.Name = "Form1";
      this.Text = "Zip Code Server - OnExecute";

    }
		#endregion

		[STAThread]
		static void Main() {
			Application.Run(new Form1());
		}

    public class UserData {
      public int FRequestCount;
    }

    private void TCPServerConnect(Context AContext) {
      AContext.Connection.IOHandler.WriteLn("200 Zip Code Server Ready.");
      AContext.Data = new UserData();
    }

    private void TCPServerExecute(Context AContext) {
      IOStream LIOH = AContext.Connection.IOHandler;
      string LLine = LIOH.ReadLn();
      try {
        string[] LArgs = LLine.Split(" ".ToCharArray());
        string LCmd = (LArgs.Length > 0 ? LArgs[0].ToUpper() : "");
        if (LCmd == "QUIT") {
          LIOH.WriteLn("202-Paka!");
          LIOH.WriteLn("202 " + ((UserData)AContext.Data).FRequestCount.ToString() + " requests processed.");
          AContext.Connection.Disconnect();
        }
        else if (LCmd == "LOOKUP") {
          LIOH.WriteLn("201 Data follows");
          for (int i = 1; i <= LArgs.Length - 1; i++) {
            string LCity = FZipCodeList[LArgs[i]];
            if (LCity != "") {
              ((UserData)AContext.Data).FRequestCount++;
              LIOH.WriteLn(LArgs[i] + ": " + LCity);
            }
          }
          LIOH.WriteLn(".");
        }
        else if (LCmd == "HELP") {
          LIOH.WriteBufferOpen();
          try {
            LIOH.WriteLn("100 Help follows");
            LIOH.WriteLn("Help");
            LIOH.WriteLn("  Provides a list of supported commands.");
            LIOH.WriteLn("Lookup <Zip Code 1> <Zip Code 2> ...");
            LIOH.WriteLn("  Looks up and provides associated cities for specified zip codes.");
            LIOH.WriteLn("Quit");
            LIOH.WriteLn("  Signals server that a disconnect is requested.");
            LIOH.WriteLn(".");
          }
          finally {
            LIOH.WriteBufferClose();
          }
        } 
        else {
          LIOH.WriteLn("400 Unknown Command");
        }
      }
      catch (Exception E) {
        LIOH.WriteLn("500-Unknown Internal Error");
        LIOH.WriteLn("500 " + E.Message.Replace(IdGlobal.EOL, " "));
        throw;
      }
    }
  }
}
